package com.lei.bbs.util;


public class EqualEmpty {


}
