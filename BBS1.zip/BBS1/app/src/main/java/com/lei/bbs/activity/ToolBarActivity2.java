package com.lei.bbs.activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.lei.bbs.R;

public class ToolBarActivity2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tool_bar2);
    }
}
