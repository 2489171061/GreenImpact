package com.lei.bbs.bean;

public class Entity {

}
