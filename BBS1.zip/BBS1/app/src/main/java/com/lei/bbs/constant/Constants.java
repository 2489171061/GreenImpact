package com.lei.bbs.constant;



public class Constants {

    public static String base_url="https://www.szitu.top/bbsServer/";

    public static boolean onLine = false;

    //user info
    public static int userId = 0;
    public static String userName = "";
    public static int level =1;
    public static String sex = "";
    public static String avatar = "";

    //userInfo
    public static String SHARE_USER_INFO = "userInfo";
    //public static String SHARE_AVATAR = "imgHead";







}
