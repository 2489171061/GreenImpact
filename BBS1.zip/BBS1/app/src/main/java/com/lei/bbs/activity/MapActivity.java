package com.lei.bbs.activity;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v7.app.AppCompatActivity;
import com.lei.bbs.R;
import com.lei.bbs.util.imageLoader.MagicImageLoader;

public class MapActivity extends FragmentActivity {
  /*  @Override protected void onCreate(Bundle savedInstanceState) { super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_map);
    }*/

}

