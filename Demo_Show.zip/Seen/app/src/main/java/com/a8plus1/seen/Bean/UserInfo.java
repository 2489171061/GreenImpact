package com.a8plus1.seen.Bean;

public class UserInfo {//存储用户信息
    public static String userID="";
    public static String nickname="";
    public static String signature="";
    public static String headImage = "";
    public static String token = "";

    public static void clean(){
        userID="";
        nickname="";
        signature="";
        headImage = "";
        token = "";
    }
}



















































